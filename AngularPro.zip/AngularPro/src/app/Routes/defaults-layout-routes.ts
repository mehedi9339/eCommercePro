import { Routes } from '@angular/router';

export const DEFAULT_ROUTES: Routes = [
    {
        path: '',
        loadChildren: () => import('../Modules/cms/cms.module').then(m => m.CmsModule)
    }
]