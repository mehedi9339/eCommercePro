import { Routes } from '@angular/router';
import { CategoriesComponent } from '../Components/Admin/Category/categories/categories.component';
import { ColorsComponent } from '../Components/Admin/Color/colors/colors.component';
import { CurriersComponent } from '../Components/Admin/Currier/curriers/curriers.component';
import { DistrictsComponent } from '../Components/Admin/District/districts/districts.component';
import { ModelsComponent } from '../Components/Admin/Model/models/models.component';
import { ProductTypesComponent } from '../Components/Admin/ProductType/product-types/product-types.component';
import { ShippingAddressesComponent } from '../Components/Admin/ShippingAddress/shipping-addresses/shipping-addresses.component';
import { SizesComponent } from '../Components/Admin/Size/sizes/sizes.component';
import { ThanasComponent } from '../Components/Admin/Thana/thanas/thanas.component';
import { UnitsComponent } from '../Components/Admin/Unit/units/units.component';

export const BACKEND_ROUTES: Routes = [
    {
        path: '',
        loadChildren: () => import('../Modules/dashboard/dashboard.module').then(m => m.DashboardModule)
    },
    {
        path: 'auth',
        loadChildren: () => import('../Modules/auth/auth.module').then(m => m.AuthModule)
    },
    {
        path: 'category', component: CategoriesComponent
    },
    {
        path: 'thana', component: ThanasComponent
    },
    {
        path: 'district', component: DistrictsComponent
    },
    {
        path: 'color', component: ColorsComponent
    },
    {
        path: 'currier', component: CurriersComponent
    },
    {
        path: 'model', component: ModelsComponent
    },
    {
        path: 'type', component: ProductTypesComponent
    },
    {
        path: 'shippingaddress', component: ShippingAddressesComponent
    },
    {
        path: 'size', component: SizesComponent
    },
    {
        path: 'unit', component: UnitsComponent
    },
    {
        path: 'dashboard',
        loadChildren: () => import('../Modules/dashboard/dashboard.module').then(m => m.DashboardModule)
    },
    {
        path: 'product',
        loadChildren: () => import('../Modules/product/product.module').then(m => m.ProductModule)
    },
]