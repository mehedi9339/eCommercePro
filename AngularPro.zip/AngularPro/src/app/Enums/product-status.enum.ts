export enum ProductStatus {
    Available,
    NotAvailable,
    Expired
}
