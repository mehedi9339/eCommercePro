export enum DeliveryStatus {
    Pending,
    OnGoing,
    Delivered
}
