export enum PayMethod {
    Paypal
}
