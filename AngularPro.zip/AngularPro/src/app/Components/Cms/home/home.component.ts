import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products;

  constructor(private service: CommonService) { }

  ngOnInit(): void {
    this.loadProducts();
  }
  loadProducts() {
    this.service.getAll("Home/products").subscribe(s => {
      console.log(s);
      this.products = s;
    })
  };

}
