import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { District } from 'src/app/Models/district';
import { CommonService } from 'src/app/Services/common.service';
import { EditDistrictComponent } from '../edit-district/edit-district.component';

@Component({
  selector: 'app-districts',
  templateUrl: './districts.component.html',
  styleUrls: ['./districts.component.css']
})
export class DistrictsComponent implements OnInit {
  title = 'District list';
  buttonstatus = true;
  isSubmitted = '';
  submitted = false;
  userTable: FormGroup;
  control: FormArray;
  districtList: any = [];
  selectedGroup: any;
  editableRows: boolean = false;
  public district: District;
  districts;

  constructor(
    private fb: FormBuilder,
    private service: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private titleService: Title
  ) { }

  ngOnInit(): void {
    this.titleService.setTitle(this.title);

    this.loadDistricts();

    this.userTable = this.fb.group({
      tableRows: this.fb.array([])
    });
  }

  loadDistricts() {
    this.service.getAll("Districts").subscribe(s => {
      console.log(s);
      this.districts = s;
    })
  }

  // Delete Function
  Delete(id) {
    this.service.delete("Districts", id).subscribe(s => {
      console.log(s);
      this.loadDistricts();
      this.toastr.warning("Deleted Successfully", 'Success!')
    })
  }

  inputChange() {
    this.buttonstatus = false;
  }

  initiateForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],

      isEditable: [false]
    });
  }

  get getFormControls() {
    const control = this.userTable.get('tableRows') as FormArray;
    return control;
  }
  deleteRow(index: number) {
    const control = this.userTable.get('tableRows') as FormArray;
    control.removeAt(index);
    if (control.length == 0) {
      this.buttonstatus = false;
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.userTable.invalid) {

      return;
    }


    console.log(this.userTable.value)
    this.districtList = this.userTable.value;
    console.log(this.districtList.tableRows[0]);

    for (var val of this.districtList.tableRows) {
      this.service.save("Districts", {
        DistrictId: 0,
        Name: val.name
      }).subscribe(s => {
        console.log(s);
      })
    }
    this.router.navigateByUrl("/backend/district");
    location.reload();
    this.toastr.info("Saved Successfully", 'Success!')
  }
  addRow() {
    this.editableRows = true;
    if (this.selectedGroup) {
      let control = this.userTable.get('tableRows') as FormArray;
      var count = this.selectedGroup;

      for (let i = 0; i < count; i++) {
        control.push(this.initiateForm());
      }
      console.log(count);
      this.buttonstatus = true;
      this.isSubmitted = 'true';
    }
    else {
      this.isSubmitted = 'false';
    }
  }

  openDialog(district) {
    const dialogRef = this.dialog.open(EditDistrictComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result: ${result}');
    });

    this.service.district = district;
    console.log(this.service.district);
  }
}
