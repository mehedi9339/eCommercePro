import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-edit-district',
  templateUrl: './edit-district.component.html',
  styleUrls: ['./edit-district.component.css']
})
export class EditDistrictComponent implements OnInit {
  data;
  constructor(
    private service: CommonService,
    private toastr: ToastrService
  ) { }

  DistrictFormControl = new FormControl('', [
    Validators.required
  ]);

  ngOnInit(): void {
    this.data = this.service.district;
    console.log(this.data);
  }

  // Update Function
  onSubmitUpdate() {
    console.log(this.data);
    this.service.update("Districts/" + this.data.districtId, this.data).subscribe(s => {
      this.toastr.info("Updated Successfully", 'Success!')
    })
  }
}
