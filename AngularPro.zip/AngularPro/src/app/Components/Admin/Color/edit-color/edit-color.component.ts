import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-edit-color',
  templateUrl: './edit-color.component.html',
  styleUrls: ['./edit-color.component.css']
})
export class EditColorComponent implements OnInit {
  data;
  constructor(
    private service: CommonService,
    private toastr: ToastrService
  ) { }

  ColorFormControl = new FormControl('', [
    Validators.required
  ]);

  ngOnInit(): void {
    this.data = this.service.color;
    console.log(this.data);
  }

  // Update Function
  onSubmitUpdate() {
    console.log(this.data);
    this.service.update("Colors/" + this.data.id, this.data).subscribe(s => {
      this.toastr.info("Updated Successfully", 'Success!')
    })
  }
}
