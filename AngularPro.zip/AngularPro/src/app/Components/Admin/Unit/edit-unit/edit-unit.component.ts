import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-unit',
  templateUrl: './edit-unit.component.html',
  styleUrls: ['./edit-unit.component.css']
})
export class EditUnitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
