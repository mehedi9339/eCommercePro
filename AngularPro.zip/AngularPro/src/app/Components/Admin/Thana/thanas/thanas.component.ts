import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thanas',
  templateUrl: './thanas.component.html',
  styleUrls: ['./thanas.component.css']
})
export class ThanasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
