import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-thana',
  templateUrl: './edit-thana.component.html',
  styleUrls: ['./edit-thana.component.css']
})
export class EditThanaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
