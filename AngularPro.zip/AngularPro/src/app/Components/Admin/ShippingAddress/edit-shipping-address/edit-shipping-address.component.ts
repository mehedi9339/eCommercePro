import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-shipping-address',
  templateUrl: './edit-shipping-address.component.html',
  styleUrls: ['./edit-shipping-address.component.css']
})
export class EditShippingAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
