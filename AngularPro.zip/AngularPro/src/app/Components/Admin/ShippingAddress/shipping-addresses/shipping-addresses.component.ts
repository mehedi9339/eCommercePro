import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-addresses',
  templateUrl: './shipping-addresses.component.html',
  styleUrls: ['./shipping-addresses.component.css']
})
export class ShippingAddressesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
