import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-types',
  templateUrl: './product-types.component.html',
  styleUrls: ['./product-types.component.css']
})
export class ProductTypesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
