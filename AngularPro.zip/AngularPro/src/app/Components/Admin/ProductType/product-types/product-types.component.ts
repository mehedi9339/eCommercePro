import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductType } from 'src/app/Models/product-type';
import { CommonService } from 'src/app/Services/common.service';
import { EditProductTypeComponent } from '../edit-product-type/edit-product-type.component';

@Component({
  selector: 'app-product-types',
  templateUrl: './product-types.component.html',
  styleUrls: ['./product-types.component.css']
})
export class ProductTypesComponent implements OnInit {
  title = 'Product Types';
  buttonstatus = true;
  isSubmitted = '';
  submitted = false;
  userTable: FormGroup;
  control: FormArray;
  typeList: any = [];
  selectedGroup: any;
  editableRows: boolean = false;
  public type: ProductType;
  types;

  constructor(
    private fb: FormBuilder,
    private service: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private titleService: Title
  ) { }

  ngOnInit(): void {
    this.titleService.setTitle(this.title);

    this.loadTypes();

    this.userTable = this.fb.group({
      tableRows: this.fb.array([])
    });
  }

  loadTypes() {
    this.service.getAll("ProductTypes").subscribe(s => {
      console.log(s);
      this.types = s;
    })
  }

  // Delete Function
  Delete(id) {
    this.service.delete("ProductTypes", id).subscribe(s => {
      console.log(s);
      this.loadTypes();
      this.toastr.warning("Deleted Successfully", 'Success!')
    })
  }

  inputChange() {
    this.buttonstatus = false;
  }

  initiateForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],

      isEditable: [false]
    });
  }

  get getFormControls() {
    const control = this.userTable.get('tableRows') as FormArray;
    return control;
  }
  deleteRow(index: number) {
    const control = this.userTable.get('tableRows') as FormArray;
    control.removeAt(index);
    if (control.length == 0) {
      this.buttonstatus = false;
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.userTable.invalid) {

      return;
    }


    console.log(this.userTable.value)
    this.typeList = this.userTable.value;
    console.log(this.typeList.tableRows[0]);

    for (var val of this.typeList.tableRows) {
      this.service.save("ProductTypes", {
        Id: 0,
        Name: val.name
      }).subscribe(s => {
        console.log(s);
      })
    }
    this.router.navigateByUrl("/backend/type");
    location.reload();
    this.toastr.info("Saved Successfully", 'Success!')
  }
  addRow() {
    this.editableRows = true;
    if (this.selectedGroup) {
      let control = this.userTable.get('tableRows') as FormArray;
      var count = this.selectedGroup;

      for (let i = 0; i < count; i++) {
        control.push(this.initiateForm());
      }
      console.log(count);
      this.buttonstatus = true;
      this.isSubmitted = 'true';
    }
    else {
      this.isSubmitted = 'false';
    }
  }

  openDialog(type) {
    const dialogRef = this.dialog.open(EditProductTypeComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result: ${result}');
    });

    this.service.productType = type;
    console.log(this.service.productType);
  }
}
