import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-product-type',
  templateUrl: './edit-product-type.component.html',
  styleUrls: ['./edit-product-type.component.css']
})
export class EditProductTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
