import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-model',
  templateUrl: './edit-model.component.html',
  styleUrls: ['./edit-model.component.css']
})
export class EditModelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
