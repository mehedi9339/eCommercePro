import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-currier',
  templateUrl: './edit-currier.component.html',
  styleUrls: ['./edit-currier.component.css']
})
export class EditCurrierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
