import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-curriers',
  templateUrl: './curriers.component.html',
  styleUrls: ['./curriers.component.css']
})
export class CurriersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
