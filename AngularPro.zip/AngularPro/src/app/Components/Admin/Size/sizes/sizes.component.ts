import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Size } from 'src/app/Models/size';
import { CommonService } from 'src/app/Services/common.service';
import { EditSizeComponent } from '../edit-size/edit-size.component';

@Component({
  selector: 'app-sizes',
  templateUrl: './sizes.component.html',
  styleUrls: ['./sizes.component.css']
})
export class SizesComponent implements OnInit {
  title = 'Size list';
  buttonstatus = true;
  isSubmitted = '';
  submitted = false;
  userTable: FormGroup;
  control: FormArray;
  sizeList: any = [];
  selectedGroup: any;
  editableRows: boolean = false;
  public size: Size;
  sizes;

  constructor(
    private fb: FormBuilder,
    private service: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private titleService: Title
  ) { }

  ngOnInit(): void {
    this.titleService.setTitle(this.title);

    this.loadSizes();

    this.userTable = this.fb.group({
      tableRows: this.fb.array([])
    });
  }

  loadSizes() {
    this.service.getAll("Sizes").subscribe(s => {
      console.log(s);
      this.sizes = s;
    })
  }

  // Delete Function
  Delete(id) {
    this.service.delete("Sizes", id).subscribe(s => {
      console.log(s);
      this.loadSizes();
      this.toastr.warning("Deleted Successfully", 'Success!')
    })
  }

  inputChange() {
    this.buttonstatus = false;
  }

  initiateForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],

      isEditable: [false]
    });
  }

  get getFormControls() {
    const control = this.userTable.get('tableRows') as FormArray;
    return control;
  }
  deleteRow(index: number) {
    const control = this.userTable.get('tableRows') as FormArray;
    control.removeAt(index);
    if (control.length == 0) {
      this.buttonstatus = false;
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.userTable.invalid) {

      return;
    }


    console.log(this.userTable.value)
    this.sizeList = this.userTable.value;
    console.log(this.sizeList.tableRows[0]);

    for (var val of this.sizeList.tableRows) {
      this.service.save("Sizes", {
        Id: 0,
        Name: val.name
      }).subscribe(s => {
        console.log(s);
      })
    }
    this.router.navigateByUrl("/backend/size");
    location.reload();
    this.toastr.info("Saved Successfully", 'Success!')
  }
  addRow() {
    this.editableRows = true;
    if (this.selectedGroup) {
      let control = this.userTable.get('tableRows') as FormArray;
      var count = this.selectedGroup;

      for (let i = 0; i < count; i++) {
        control.push(this.initiateForm());
      }
      console.log(count);
      this.buttonstatus = true;
      this.isSubmitted = 'true';
    }
    else {
      this.isSubmitted = 'false';
    }
  }

  openDialog(size) {
    const dialogRef = this.dialog.open(EditSizeComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result: ${result}');
    });

    this.service.size = size;
    console.log(this.service.size);
  }
}
