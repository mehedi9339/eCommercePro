import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-edit-size',
  templateUrl: './edit-size.component.html',
  styleUrls: ['./edit-size.component.css']
})
export class EditSizeComponent implements OnInit {
  data;
  constructor(
    private service: CommonService,
    private toastr: ToastrService
  ) { }

  DistrictFormControl = new FormControl('', [
    Validators.required
  ]);

  ngOnInit(): void {
    this.data = this.service.size;
    console.log(this.data);
  }

  // Update Function
  onSubmitUpdate() {
    console.log(this.data);
    this.service.update("Sizes/" + this.data.id, this.data).subscribe(s => {
      this.toastr.info("Updated Successfully", 'Success!')
    })
  }
}
