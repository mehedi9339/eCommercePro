import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-size',
  templateUrl: './edit-size.component.html',
  styleUrls: ['./edit-size.component.css']
})
export class EditSizeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
