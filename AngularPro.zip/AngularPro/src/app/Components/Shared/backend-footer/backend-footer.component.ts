import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-backend-footer',
  templateUrl: './backend-footer.component.html',
  styleUrls: ['./backend-footer.component.css']
})
export class BackendFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
