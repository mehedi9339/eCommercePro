import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/Services/common.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  rootCategories;
  constructor(private service: CommonService) { }

  ngOnInit(): void {
    this.loadRootCategories();
  }
  loadRootCategories() {
    this.service.getAll("Home/getcategory").subscribe(s => {
      console.log(s);
      this.rootCategories = s;
    })
  }

}
