import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { District } from '../Models/district';
import { Color } from '../Models/color';
import { Category } from '../Models/category';
import { Currier } from '../Models/currier';
import { Models } from '../Models/models';
import { ProductType } from '../Models/product-type';
import { ShippingAddress } from '../Models/shipping-address';
import { Size } from '../Models/size';
import { Thana } from '../Models/thana';
import { Unit } from '../Models/unit';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  category: Category;
  color: Color;
  currier: Currier;
  district: District;
  model: Models;
  productType: ProductType;
  shippingAddress: ShippingAddress;
  size: Size;
  thana: Thana;
  unit: Unit;


  constructor(private http: HttpClient) { }

  getAll(controller) {
    var tokenHeader = new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('myToken') });
    return this.http.get(environment.apiUrl + controller, { headers: tokenHeader });
  }
  getById(controller, id) {
    return this.http.get(environment.apiUrl + controller + "/" + id);
  }
  saveOrUpdate(controller, data) {
    return this.http.post(environment.apiUrl + controller, data);
  }
  save(controller, data) {
    return this.http.post(environment.apiUrl + controller, data);
  }
  update(controller, data) {
    return this.http.put(environment.apiUrl + controller, data);
  }
  delete(controller, id) {
    return this.http.delete(environment.apiUrl + controller + "/" + id);
  }
  login(controller, body) {
    return this.http.post(environment.apiUrl + controller, body);
  }
  register(controller, body) {
    return this.http.post("https://localhost:44322/api" + controller, body);
  }
}
