import { PurchaseDetail } from './purchase-detail';
import { SalesDetail } from './sales-detail';
import { Stock } from './stock';

export class Size {
    Id: number;
    Name: string;

    //Navigations
    PurchaseDetails: PurchaseDetail[];
    Stocks: Stock[];
    SalesDetails: SalesDetail[];
}
