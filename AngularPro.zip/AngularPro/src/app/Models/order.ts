import { DeliveryStatus } from '../Enums/delivery-status.enum';
import { OrderStatus } from '../Enums/order-status.enum';
import { Customer } from './customer';
import { SalesMaster } from './sales-master';
import { ShippingAddress } from './shipping-address';

export class Order {
    OrderId: number;
    OrderNo: string;
    ShippingAddressId: number;
    CustomerId: number;
    OrderStatus: OrderStatus;
    OrderDate: Date;
    DeliveryStatus: DeliveryStatus;
    DeliveryDate: Date;
    ShippingDate: Date;
    DeliveryFee: number;
    PaymentStatus: number;
    TransactionId: string;
    TransactionTime: Date;
    TotalAmount: number;

    //Navigations
    ShippingAddress: ShippingAddress;
    Customer: Customer;
    SalesMaster: SalesMaster[];
}
