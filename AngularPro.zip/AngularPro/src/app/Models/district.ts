import { Currier } from './currier';
import { Customer } from './customer';
import { ShippingAddress } from './shipping-address';
import { Thana } from './thana';

export class District {
    DistrictId: number;
    Name: string

    //Navigations
    Thanas: Thana[];
    Customers: Customer[];
    shippingAddresses: ShippingAddress[];
    Curriers: Currier[];
}
