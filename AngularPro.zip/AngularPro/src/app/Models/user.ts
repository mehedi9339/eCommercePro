import { Customer } from './customer';
import { PurchaseDetail } from './purchase-detail';

export class User {
    FirstName: string;
    LastName: string;
    Photo: string;

    Customer: Customer[];
    PurchaseDetail:PurchaseDetail[];
}
