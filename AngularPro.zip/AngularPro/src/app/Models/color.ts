import { PurchaseDetail } from './purchase-detail';
import { SalesDetail } from './sales-detail';
import { Stock } from './stock';

export class Color {
    Id: number
    Name: string;

    //Navigations
    PurchaseDetail: PurchaseDetail[];
    Stock: Stock[];
    SalesDetail: SalesDetail[];
}
