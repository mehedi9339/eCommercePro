import { Product } from './product';

export class Unit {
    UnitId: number;
    Name: string;
    ShortName: string;

    //Navigations
    Products: Product[];
}
