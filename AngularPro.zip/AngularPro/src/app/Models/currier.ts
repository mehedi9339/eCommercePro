import { District } from './district';
import { ShippingAddress } from './shipping-address';
import { Thana } from './thana';

export class Currier {
    CurrierId: number;
    Name: string;
    DistrictId: number;
    ThanaId: number;
    Phone: string;

    //Navigations
    District: District;
    Thana: Thana;
    ShippingAddresses: ShippingAddress[];
}
