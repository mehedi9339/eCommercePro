import { Color } from './color';
import { Models } from './models';
import { Product } from './product';
import { SalesMaster } from './sales-master';
import { Size } from './size';

export class SalesDetail {
    SalesDetailId: number;
    SalesMasterId: number;
    UintPrice: number;
    UnitQuantity: number;
    ModelId?: number;
    ColorId?: number;
    SizeId?: number;
    VatRate: number;
    VatAmount: number;
    DiscountRate: number;
    DiscountAmount: number;
    NetAmount: number;
    ProductId: number;

    //Navigations
    SalesMaster: SalesMaster;
    Product: Product;
    ModelTbl: Models;
    Color: Color;
    Size: Size;
}
