import { Product } from './product';

export class Category {
    CategoryId: number;
    Name: string;
    Description: string;
    ParentId: number;

    //Navigations
    Products: Product[];
}
