import { Customer } from './customer';
import { Product } from './product';

export class WishList {
    WishListId: number;
    CustomerId: number;
    ProductId: number
    Quantity: number

    //Navigations
    Customer: Customer;
    Product: Product;
}
