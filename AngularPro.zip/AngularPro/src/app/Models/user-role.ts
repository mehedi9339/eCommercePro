export class UserRole {
}
