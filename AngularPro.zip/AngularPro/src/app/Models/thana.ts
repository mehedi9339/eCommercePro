import { Currier } from './currier';
import { Customer } from './customer';
import { District } from './district';
import { ShippingAddress } from './shipping-address';

export class Thana {
    ThanaId: number;
    Name: string
    DistrictId: number;

    //Navigations
    District: District;
    Customers: Customer[];
    shippingAddresses: ShippingAddress[];
    Curriers: Currier[];
}
