import { PurchaseDetail } from './purchase-detail';
import { SalesDetail } from './sales-detail';
import { Stock } from './stock';

export class Models {
    Id: number;
    Name: string;

    //Navigations
    PurchaseDetails: PurchaseDetail[];
    Stocks: Stock[];
    SalesDetails: SalesDetail[];
}
