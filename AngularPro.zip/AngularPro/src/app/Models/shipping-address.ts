import { Currier } from './currier';
import { Customer } from './customer';
import { District } from './district';
import { Order } from './order';
import { Thana } from './thana';

export class ShippingAddress {
    ShippingAddressId: number;
    Name: string;
    Phone: string;
    DistrictId: number;
    ThanaId: number;
    Address: string;
    CustomerId: number;
    CurrierId: number;

    //Navigations
    Customer: Customer;
    Thana: Thana;
    District: District;
    Currier: Currier;
    Orders: Order[];
}
