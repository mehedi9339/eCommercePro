export class ProductType {
    Id: number;
    Name: string;
}
