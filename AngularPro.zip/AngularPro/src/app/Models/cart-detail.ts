import { Cart } from './cart';
import { Product } from './product';

export class CartDetail {
    CartDetailId: number
    CartId: number;
    ProductId: number;
    Quantity: number;

    // Navigations
    Cart: Cart;
    Product: Product;
}
