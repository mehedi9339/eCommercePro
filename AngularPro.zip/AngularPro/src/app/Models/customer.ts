import { Cart } from './cart';
import { District } from './district';
import { Order } from './order';
import { ShippingAddress } from './shipping-address';
import { Thana } from './thana';
import { User } from './user';
import { WishList } from './wish-list';

export class Customer {
    CustomerId: number;
    Name: string;
    Address: string;
    ContactNo: string;
    UserId: string;
    CompanyName: string;
    Email: string;
    CompanyContact: string;
    CompanyWebsite: string;
    DistrictId: number;
    ThanaId: number;

    //Navigations
    User: User;
    Thana: Thana;
    District: District;
    ShippingAddresses: ShippingAddress[];
    WisthLists: WishList[];
    Orders: Order[];
    Carts: Cart[];
}
