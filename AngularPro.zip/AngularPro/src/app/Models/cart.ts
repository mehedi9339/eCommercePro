import { CartDetail } from './cart-detail';
import { Customer } from './customer';

export class Cart {
    CartId: number;
    CustomerId: number;

    //Navigations
    Customer: Customer;
    CartDetail: CartDetail[];
}
