import { ProductStatus } from '../Enums/product-status.enum';
import { CartDetail } from './cart-detail';
import { Category } from './category';
import { PurchaseDetail } from './purchase-detail';
import { SalesDetail } from './sales-detail';
import { Unit } from './unit';
import { WishList } from './wish-list';

export class Product {
    ProductId: number;
    CategoryId: number;
    Status: ProductStatus;
    Name: string;
    UnitId: number | null;
    ProductCode: string;
    PreviousPrice: number;
    DiscountRate: number;
    SalesDiscountRate: number;
    SalesPrice: number;
    ProductDescription: string;
    ExpireDate: Date;
    Image1: string;
    Image2: string;
    Image3: string;

    //Navigations
    Category: Category;
    Unit: Unit;
    CartDetail: CartDetail[];
    PurchaseDetail: PurchaseDetail[];
    SalesDetail: SalesDetail[];
    WishList: WishList[];
}
