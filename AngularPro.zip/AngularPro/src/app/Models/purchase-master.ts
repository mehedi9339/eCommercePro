import { PurchaseDetail } from './purchase-detail';

export class PurchaseMaster {
    PurchaseMasterId: number;
    PurchaseDate: Date;
    TotalQuantity: number;
    TotalPrice: number;
    DiscountRate: number;
    VatRate: number;
    LaborCost: number;
    VoucharNo: string;
    BillNo: string;
    Note: string;
    NetAmount: number;

    //Navigations
    PurchaseDetails: PurchaseDetail[];
}
