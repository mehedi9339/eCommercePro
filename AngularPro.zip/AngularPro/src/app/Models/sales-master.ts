import { Order } from './order';
import { SalesDetail } from './sales-detail';

export class SalesMaster {
    SalesMasterId: number;
    OrderId: number;
    SalesDate: Date;
    TotalQuantity: number;
    TotalPrice: Number;
    VoucherNo: string;
    BillNo: string;
    TotalAmount: number;
    Note: string;

    //Navigations
    Order: Order;
    SalesDetails: SalesDetail[];
}
