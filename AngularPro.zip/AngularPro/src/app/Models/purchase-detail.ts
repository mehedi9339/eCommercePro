import { Color } from './color';
import { Models } from './models';
import { Product } from './product';
import { PurchaseMaster } from './purchase-master';
import { Size } from './size';
import { User } from './user';

export class PurchaseDetail {
    PurchaseDetailId: number;
    ProductId: number;
    ProductCode: string;
    ModelId?: number;
    ColorId?: number;
    SizeId?: number;
    EntryBy: string;
    EntryDate: Date;
    UnitPrice: number;
    DiscountRate: number;
    VatRate: number;
    NetAmount: number;
    UnitQuantity: number;
    TotalPrice: number;
    Description: string
    ExpiryDate: Date;
    MasterId: number;

    //Navigations
    PurchaseMaster: PurchaseMaster;
    Product: Product;
    User: User;
    ModelTbl: Models;
    Color: Color;
    Size: Size;
}
