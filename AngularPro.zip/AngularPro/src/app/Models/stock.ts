import { Color } from './color';
import { Models } from './models';
import { Size } from './size';

export class Stock {
    StockId: number;
    StockDate: Date;
    ProductCode: string;
    ModelId: number;
    ColorId: number
    SizeId: number;
    InQuantity: number;
    OutQuantity: number;
    InStockQuantity: number;
    PurchasePrice: number;
    StockPrice: number;
    ExpiryDate: Date;
    LotNo: number;

    //Navigations
    ModelTbl: Models;
    Color: Color;
    Size: Size;
}
