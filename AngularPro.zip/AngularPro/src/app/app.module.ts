import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/Shared/header/header.component';
import { FooterComponent } from './Components/Shared/footer/footer.component';
import { BackendHeaderComponent } from './Components/Shared/backend-header/backend-header.component';
import { BackendFooterComponent } from './Components/Shared/backend-footer/backend-footer.component';
import { DefaultLayoutComponent } from './Components/Layouts/default-layout/default-layout.component';
import { BackendLayoutComponent } from './Components/Layouts/backend-layout/backend-layout.component';
import { HomeComponent } from './Components/Cms/home/home.component';
import { SignupComponent } from './Components/Cms/signup/signup.component';
import { SigninComponent } from './Components/Cms/signin/signin.component';
import { PageNotFoundComponent } from './Components/Cms/page-not-found/page-not-found.component';
import { DashboardComponent } from './Components/Dashboard/dashboard/dashboard.component';

import { SharedModule } from './Modules/shared/shared.module';
import { RegistrationComponent } from './Components/Admin/registration/registration.component';
import { LoginComponent } from './Components/Admin/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ToastrModule } from 'ngx-toastr';
import { ColorsComponent } from './Components/Admin/Color/colors/colors.component';
import { EditColorComponent } from './Components/Admin/Color/edit-color/edit-color.component';
import { DistrictsComponent } from './Components/Admin/District/districts/districts.component';
import { EditDistrictComponent } from './Components/Admin/District/edit-district/edit-district.component';
import { EditThanaComponent } from './Components/Admin/Thana/edit-thana/edit-thana.component';
import { ThanasComponent } from './Components/Admin/Thana/thanas/thanas.component';
import { CategoriesComponent } from './Components/Admin/Category/categories/categories.component';
import { EditCategoryComponent } from './Components/Admin/Category/edit-category/edit-category.component';
import { CurriersComponent } from './Components/Admin/Currier/curriers/curriers.component';
import { EditCurrierComponent } from './Components/Admin/Currier/edit-currier/edit-currier.component';
import { ModelsComponent } from './Components/Admin/Model/models/models.component';
import { EditModelComponent } from './Components/Admin/Model/edit-model/edit-model.component';
import { ProductTypesComponent } from './Components/Admin/ProductType/product-types/product-types.component';
import { EditProductTypeComponent } from './Components/Admin/ProductType/edit-product-type/edit-product-type.component';
import { SizesComponent } from './Components/Admin/Size/sizes/sizes.component';
import { EditSizeComponent } from './Components/Admin/Size/edit-size/edit-size.component';
import { ShippingAddressesComponent } from './Components/Admin/ShippingAddress/shipping-addresses/shipping-addresses.component';
import { EditShippingAddressComponent } from './Components/Admin/ShippingAddress/edit-shipping-address/edit-shipping-address.component';
import { UnitsComponent } from './Components/Admin/Unit/units/units.component';
import { EditUnitComponent } from './Components/Admin/Unit/edit-unit/edit-unit.component';


@NgModule({
  declarations: [
    AppComponent,
    //HeaderComponent,
    //FooterComponent,
    //BackendHeaderComponent,
    //BackendFooterComponent,
    DefaultLayoutComponent,
    BackendLayoutComponent,
    HomeComponent,
    SignupComponent,
    SigninComponent,
    PageNotFoundComponent,
    DashboardComponent,
    RegistrationComponent,
    LoginComponent,
    EditColorComponent,
    ColorsComponent,
    DistrictsComponent,
    EditDistrictComponent,
    EditThanaComponent,
    ThanasComponent,
    CategoriesComponent,
    EditCategoryComponent,
    CurriersComponent,
    EditCurrierComponent,
    ModelsComponent,
    EditModelComponent,
    ProductTypesComponent,
    EditProductTypeComponent,
    SizesComponent,
    EditSizeComponent,
    ShippingAddressesComponent,
    EditShippingAddressComponent,
    UnitsComponent,
    EditUnitComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    ToastrModule.forRoot()
  ],
  providers: [Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
