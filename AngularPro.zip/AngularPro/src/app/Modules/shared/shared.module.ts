import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { HeaderComponent } from 'src/app/Components/Shared/header/header.component';
import { FooterComponent } from 'src/app/Components/Shared/footer/footer.component';
import { BackendHeaderComponent } from 'src/app/Components/Shared/backend-header/backend-header.component';
import { BackendFooterComponent } from 'src/app/Components/Shared/backend-footer/backend-footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    BackendHeaderComponent,
    BackendFooterComponent
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    BackendHeaderComponent,
    BackendFooterComponent
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class SharedModule { }
