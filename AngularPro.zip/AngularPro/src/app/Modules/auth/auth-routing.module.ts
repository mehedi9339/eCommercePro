import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from 'src/app/Components/Admin/login/login.component';
import { RegistrationComponent } from 'src/app/Components/Admin/registration/registration.component';
import { SigninComponent } from 'src/app/Components/Cms/signin/signin.component';
import { SignupComponent } from 'src/app/Components/Cms/signup/signup.component';


const routes: Routes = [
  { path: '', component: RegistrationComponent },
  { path: 'signup', component: RegistrationComponent },
  { path: 'signin', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
