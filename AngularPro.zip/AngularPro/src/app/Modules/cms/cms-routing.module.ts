import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/app/Components/Cms/home/home.component';
import { PageNotFoundComponent } from 'src/app/Components/Cms/page-not-found/page-not-found.component';
import { SigninComponent } from 'src/app/Components/Cms/signin/signin.component';
import { SignupComponent } from 'src/app/Components/Cms/signup/signup.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'signin', component: SigninComponent },
  { path: '404', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmsRoutingModule { }
