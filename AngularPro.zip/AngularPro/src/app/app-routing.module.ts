import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BackendLayoutComponent } from './Components/Layouts/backend-layout/backend-layout.component';
import { DefaultLayoutComponent } from './Components/Layouts/default-layout/default-layout.component';
import { BACKEND_ROUTES } from './Routes/backend-layout-routes';
import { DEFAULT_ROUTES } from './Routes/defaults-layout-routes';


const routes: Routes = [
  { path: '', component: DefaultLayoutComponent, children: DEFAULT_ROUTES },
  { path: 'backend', component: BackendLayoutComponent, children: BACKEND_ROUTES },
  { path: '**', redirectTo: '404' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
